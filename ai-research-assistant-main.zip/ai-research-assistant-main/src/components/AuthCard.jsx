import React from "react";

const AuthCard = ({ mode, setMode, username, setUsername, password, setPassword, handleAuth, authMessage }) => {
  return (
    <div className="card auth-card">
      <h3>🔐 {mode}</h3>
      <div>
        <label>
          <input type="radio" value="Login" checked={mode === "Login"} onChange={() => setMode("Login")} /> Login
        </label>
        <label>
          <input type="radio" value="Signup" checked={mode === "Signup"} onChange={() => setMode("Signup")} /> Signup
        </label>
      </div>

      <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />

      <button onClick={handleAuth}>Continue 🚀</button>
      <p>{authMessage}</p>
    </div>
  );
};

export default AuthCard;
