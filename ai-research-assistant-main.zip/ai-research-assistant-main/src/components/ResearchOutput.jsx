import React from "react";

const ResearchOutput = ({ researchOutput }) => {
  return (
    <div className="card output-card" dangerouslySetInnerHTML={{ __html: researchOutput }}></div>
  );
};

export default ResearchOutput;
