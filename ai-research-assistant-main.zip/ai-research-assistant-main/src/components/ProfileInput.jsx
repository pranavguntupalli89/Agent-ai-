import React from "react";

const ProfileInput = ({
  profileText,
  setProfileText,
  trendingTopics,
  selectedTopic,
  setSelectedTopic,
  customTopic,
  setCustomTopic,
  handleSuggestTopics,
  handleGenerateResearch,
  handleLogout
}) => {
  return (
    <div className="card profile-card">
      <h3>👤 Faculty Profile</h3>
      <textarea rows="6" placeholder="Enter your research profile..." value={profileText} onChange={(e) => setProfileText(e.target.value)} />
      <button onClick={handleSuggestTopics}>✨ Suggest Trending Topics</button>
      {trendingTopics.length > 0 && (
        <select value={selectedTopic} onChange={(e) => setSelectedTopic(e.target.value)}>
          {trendingTopics.map((topic, idx) => <option key={idx} value={topic}>{topic}</option>)}
        </select>
      )}
      <input type="text" placeholder="Or enter a custom topic" value={customTopic} onChange={(e) => setCustomTopic(e.target.value)} />
      <button onClick={handleGenerateResearch}>🚀 Generate Detailed Research</button>
      <button onClick={handleLogout}>🔓 Logout</button>
    </div>
  );
};

export default ProfileInput;
