import React, { useState } from "react";
import "./App.css";

// ---- API KEY (placeholder for frontend usage, not safe for production) ----
const GOOGLE_API_KEY = "AIzaSyAxHn1PMfog5Ilvb_iXSxJDgXILxK-J4jQ";

function App() {
  // ---------- Authentication ----------
  const [mode, setMode] = useState("Login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [authMessage, setAuthMessage] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);

  // ---------- Research Section ----------
  const [profileText, setProfileText] = useState("");
  const [trendingTopics, setTrendingTopics] = useState([]);
  const [selectedTopic, setSelectedTopic] = useState("");
  const [customTopic, setCustomTopic] = useState("");
  const [researchOutput, setResearchOutput] = useState("");

  // ---------- Handlers ----------
  const handleAuth = () => {
    if (mode === "Login") {
      setAuthMessage(`✅ Logged in as ${username} (placeholder)`);
      setLoggedIn(true);
    } else {
      setAuthMessage(`✅ Signup successful for ${username} (placeholder)`);
    }
  };

  const handleSuggestTopics = () => {
    // Here you can eventually call Google API using GOOGLE_API_KEY
    const suggestions = ["Machine Learning", "Random Forest", "Deep Learning", "NLP"];
    setTrendingTopics(suggestions);
    setSelectedTopic(suggestions[0]);
  };

  const handleGenerateResearch = () => {
    const topic = customTopic || selectedTopic || "General AI Research";
    let output = "";

    if (topic.toLowerCase().includes("machine learning")) {
      output = `
        <div style="padding:20px; background:#fff; border-radius:12px; line-height:1.6;">
          <h2>📊 Research Topic: Machine Learning</h2>
          <p><b>Definition:</b> Machine Learning (ML) is a subfield of AI focused on developing systems that learn from data without explicit programming.</p>
          <ul>
            <li>Supervised Learning: regression, classification</li>
            <li>Unsupervised Learning: clustering, association</li>
            <li>Reinforcement Learning: trial and error-based learning</li>
          </ul>
          <p><b>Applications:</b> Healthcare, Finance, Transportation, Education</p>
        </div>
      `;
    } else if (topic.toLowerCase().includes("random forest")) {
      output = `
        <div style="padding:20px; background:#fff; border-radius:12px; line-height:1.6;">
          <h2>📊 Research Topic: Random Forest</h2>
          <p><b>Definition:</b> Random Forest is an ensemble learning method combining multiple decision trees for accurate predictions.</p>
          <ul>
            <li>Bootstrapped datasets for each tree</li>
            <li>Random subset of features for each tree</li>
            <li>Majority voting for final prediction</li>
          </ul>
          <p><b>Applications:</b> Medical diagnosis, Credit risk analysis, Customer segmentation</p>
        </div>
      `;
    } else if (topic.toLowerCase().includes("deep learning")) {
      output = `
        <div style="padding:20px; background:#fff; border-radius:12px; line-height:1.6;">
          <h2>📊 Research Topic: Deep Learning</h2>
          <p><b>Definition:</b> Deep Learning uses multi-layer neural networks to learn high-level abstractions from data.</p>
          <ul>
            <li>CNNs: image analysis, computer vision</li>
            <li>RNNs / LSTMs: sequence and time-series modeling</li>
            <li>Transformers: modern NLP models</li>
          </ul>
          <p><b>Applications:</b> Speech recognition, Autonomous driving, Medical image analysis</p>
        </div>
      `;
    } else if (topic.toLowerCase().includes("nlp")) {
      output = `
        <div style="padding:20px; background:#fff; border-radius:12px; line-height:1.6;">
          <h2>📊 Research Topic: Natural Language Processing (NLP)</h2>
          <p><b>Definition:</b> NLP bridges human communication and computers using linguistics, statistics, and AI.</p>
          <ul>
            <li>Text Classification & Sentiment Analysis</li>
            <li>Machine Translation</li>
            <li>Speech Recognition & Chatbots</li>
            <li>Text Summarization</li>
          </ul>
          <p><b>Applications:</b> Chatbots, Translation, Speech recognition, Content analysis</p>
        </div>
      `;
    } else {
      output = `
        <div style="padding:20px; background:#fff; border-radius:12px; line-height:1.6;">
          <h2>📊 Research Topic: ${topic}</h2>
          <p>This topic explores interdisciplinary advancements, real-world applications, and AI-driven innovation.</p>
        </div>
      `;
    }

    setResearchOutput(output);
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setAuthMessage("");
    setUsername("");
    setPassword("");
    setProfileText("");
    setTrendingTopics([]);
    setSelectedTopic("");
    setCustomTopic("");
    setResearchOutput("");
  };

  return (
    <div className="app-container">
      <h1>⚡ AI Research Assistant — Faculty Research Hub</h1>

      {!loggedIn && (
        <div className="card auth-card">
          <h3>🔐 {mode}</h3>
          <div>
            <label>
              <input type="radio" value="Login" checked={mode === "Login"} onChange={() => setMode("Login")} /> Login
            </label>
            <label>
              <input type="radio" value="Signup" checked={mode === "Signup"} onChange={() => setMode("Signup")} /> Signup
            </label>
          </div>

          <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />

          <button onClick={handleAuth}>Continue 🚀</button>
          <p>{authMessage}</p>
        </div>
      )}

      {loggedIn && (
        <div className="research-section">
          <div className="card profile-card">
            <h3>👤 Faculty Profile</h3>
            <textarea rows="6" placeholder="Enter your research profile..." value={profileText} onChange={(e) => setProfileText(e.target.value)} />
            <button onClick={handleSuggestTopics}>✨ Suggest Trending Topics</button>

            {trendingTopics.length > 0 && (
              <select value={selectedTopic} onChange={(e) => setSelectedTopic(e.target.value)}>
                {trendingTopics.map((topic, idx) => <option key={idx} value={topic}>{topic}</option>)}
              </select>
            )}

            <input type="text" placeholder="Or enter a custom topic" value={customTopic} onChange={(e) => setCustomTopic(e.target.value)} />
            <button onClick={handleGenerateResearch}>🚀 Generate Detailed Research</button>
            <button onClick={handleLogout}>🔓 Logout</button>
          </div>

          <div className="card output-card" dangerouslySetInnerHTML={{ __html: researchOutput }}></div>
        </div>
      )}
    </div>
  );
}

export default App;
